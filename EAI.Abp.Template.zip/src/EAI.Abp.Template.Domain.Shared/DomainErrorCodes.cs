﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public static class DomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
