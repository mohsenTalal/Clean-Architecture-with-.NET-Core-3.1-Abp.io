﻿using System;
using System.Collections.Generic;
using System.Text;
using $safeprojectname$;
using Volo.Abp.Modularity;

namespace $safeprojectname$
{
    public class ApplicationContractsModule : AbpModule
    {

    }
}
