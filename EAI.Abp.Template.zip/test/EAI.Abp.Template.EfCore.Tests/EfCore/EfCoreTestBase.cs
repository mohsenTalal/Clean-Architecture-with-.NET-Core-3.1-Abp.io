﻿using System;
using System.Collections.Generic;
using System.Text;
using $ext_safeprojectname$.TestBase;

namespace $safeprojectname$
{
    public abstract class EfCoreTestBase : TestBase<EfCoreTestModule>
    {

    }
}
