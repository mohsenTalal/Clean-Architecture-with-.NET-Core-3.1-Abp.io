﻿using $ext_safeprojectname$.TestBase;

namespace $safeprojectname$
{
    public abstract class DomainTestBase : TestBase<DomainTestModule>
    {

    }
}
